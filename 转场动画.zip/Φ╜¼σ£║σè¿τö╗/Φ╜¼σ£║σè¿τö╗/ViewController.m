//
//  ViewController.m
//  转场动画
//
//  Created by 周松岩 on 2016/7/16.
//  Copyright © 2016年 SoYoung. All rights reserved.
//

#import "ViewController.h"

NSString * const fade = @"fade";
NSString * const push = @"push";
NSString * const moveIn = @"moveIn";
NSString * const reveal = @"reveal";
NSString * const cube = @"cube";
NSString * const oglFlip = @"oglFlip";
NSString * const suckEffect = @"suckEffect";
NSString * const rippleEffect = @"rippleEffect";
NSString * const pageCurl = @"pageCurl";
NSString * const pageUnCurl = @"pageUnCurl";
NSString * const cameraIrisHollowOpen = @"cameraIrisHollowOpen";
NSString * const cameraIrisHollowClose = @"cameraIrisHollowClose";


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

static int _i = 1;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}
- (IBAction)fade:(id)sender
{
    [self CATransitionWithType:fade];
}
- (IBAction)push:(id)sender
{
    [self CATransitionWithType:push];
}
- (IBAction)moveIn:(id)sender
{
    [self CATransitionWithType:moveIn];
}
- (IBAction)reveal:(id)sender
{
    [self CATransitionWithType:reveal];
}
- (IBAction)cube:(id)sender
{
    [self CATransitionWithType:cube];
}
- (IBAction)oglFlip:(id)sender
{
    [self CATransitionWithType:oglFlip];
}
- (IBAction)suckEffect:(id)sender
{
    [self CATransitionWithType:suckEffect];
}
- (IBAction)rippleEffect:(id)sender
{
    [self CATransitionWithType:rippleEffect];
}
- (IBAction)pageCurl:(id)sender
{
    [self CATransitionWithType:pageCurl];
}
- (IBAction)pageUncurl:(id)sender
{
    [self CATransitionWithType:pageUnCurl];
}
- (IBAction)cameraIrisHollowOpen:(id)sender
{
    [self CATransitionWithType:cameraIrisHollowOpen];
}
- (IBAction)cameraIrisHollowClose:(id)sender
{
    [self CATransitionWithType:cameraIrisHollowClose];
}


- (void)CATransitionWithType:(NSString *)type
{
    
    //转场代码必须得要和转场动画在同一个方法当中.
    //创建动画
    CATransition *anim = [CATransition animation];
    
    //设置转场类型
    anim.type = type;
    
    //设置转场的方向
    anim.subtype = kCATransitionFromLeft;
    //设置动画的开始点.
    anim.startProgress = 0.2;
    //设置动画的结束点.
    anim.endProgress = 0.8;
    
    anim.duration = 1;
    [self.imageV.layer addAnimation:anim forKey:nil];
    
    //转场代码
    
    _i++;
    if (_i > 3) {
        _i = 1;
    }
    NSString *imageName = [NSString stringWithFormat:@"%d",_i];
    self.imageV.image = [UIImage imageNamed:imageName];
    
}

@end
